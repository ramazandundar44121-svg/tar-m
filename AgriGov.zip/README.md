
# Tarım & Orman — Profesyonel Web Şablonu

## Hızlı Kurulum
- Dosyaları hostinginize yükleyin (cPanel, Netlify, Vercel vb.).
- Giriş: `index.html`
- Stil: `assets/css/style.css`
- Script: `assets/js/main.js`

## Ana Sayfa Logosu
- `assets/img/minister-logo.svg` bir **yer tutucu** görseldir. Resmi logoyu kullanacaksanız ilgili kurumun telif/marka kurallarına uyarak SVG/PNG ile değiştirin.

## Gizli Admin Paneli
- Adres: `/_admin/` (robots.txt ile arama motorlarına kapalı).
- Varsayılan giriş: **admin / 123456** (tarayıcı `localStorage`'da saklanır, lütfen değiştirin).
- Duyuru ekleyebilir/silebilir; ana sayfadaki "Duyurular" bölümünde görüntülenir.
- Not: Bu panel istemci taraflıdır (statik hosting uyumlu). Gerçek sistemde sunucu tarafı kimlik doğrulama + veritabanı önerilir.

## Sayfalar
- `hakkimizda.html` — Kurumsal yapı.
- `programlar.html` — Destek ve teşvikler.
- `teknolojiler.html` — Yeni teknolojiler.
- `kuresel.html` — Dünyadaki bakanlıklara genel bakış.
- `iletisim.html` — İletişim formu.
- `arama.html` — Basit arama.
